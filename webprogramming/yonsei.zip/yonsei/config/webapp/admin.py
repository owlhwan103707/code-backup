from django.contrib import admin
from .models import Bible #4장 추가
# Register your models here.
admin.site.register(Bible) #4장 추가